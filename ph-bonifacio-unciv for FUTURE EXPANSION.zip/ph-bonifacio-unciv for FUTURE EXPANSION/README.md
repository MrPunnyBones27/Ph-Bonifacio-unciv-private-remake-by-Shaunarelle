# ph-bonifacio-unciv

## Philippines Mod for Unciv 

A mod featuring the Philippines with the Leader Andres Bonifacio

Leader: Andres Bonifacio 

Title: Supreme Leader of the Katipunan

#### Unique Bonus: Sovereign Tagalog Nation

+1 Production from Farm

#### Unique Building: IRRI (International Rice Research Institute)

Unlocked on Education. Replaces University.
+10% food,+25% Science, and +2 Science from Farm tiles.

#### Unique Unit: Katipunero

Replaces Rifleman. Woodsman promotion, production cost of 180 (regular rifleman cost is 225), while base combat strength reduced to 28 from 34.

## Suggestions? Bugs?

Feel free to add issues in the repository. Note that it might take me a week or two to solve them.

## Credits  

All credits are written at credits.txt



